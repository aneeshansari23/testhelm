{{- define "mlabels"  -}}
app: mango

{{- end }}
